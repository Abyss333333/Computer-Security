#!/bin/bash

./bin/named -f -g -4 -c ./etc/named.conf -U 1
